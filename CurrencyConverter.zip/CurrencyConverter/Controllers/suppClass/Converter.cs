﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace CurrencyConverter.Controllers.suppClass
{
    public class Converter
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<Converter> _logger;
        public Converter(ILogger<Converter> logger, IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            _httpClientFactory = httpClientFactory;
        }
        public object convert(string c_from, string c_to, string amount)
        {
            // fetching the exchange rate value from server
            var httpClient = _httpClientFactory.CreateClient();
            try
            {

                var response = httpClient.GetAsync("https://v6.exchangerate-api.com/v6/216ab912c6665d868050e79e/pair/" + c_from + "/" + c_to + "/").Result;
                if (response.IsSuccessStatusCode)
                {
                    var data = response.Content.ReadAsAsync<object>().Result;
                    return data;
                }
                else
                {
                    var result = $"{(int)response.StatusCode} ({response.ReasonPhrase})";
                    return "sorry failed converting your currencies " + result;
                }
            }
            catch
            {
                return "No connection to server";
            }
        }

        //this method is for getting requested list of currencies with their current rates
        public object getList(string currency)
        {
            // fetching the exchange rate value from server
            var httpClient = _httpClientFactory.CreateClient();
            try
            {

                var response = httpClient.GetAsync("https://v6.exchangerate-api.com/v6/216ab912c6665d868050e79e/latest/" + currency).Result;
                if (response.IsSuccessStatusCode)
                {
                    var data = response.Content.ReadAsAsync<object>().Result;
                    return data;
                }
                else
                {
                    var result = $"{(int)response.StatusCode} ({response.ReasonPhrase})";
                    return "sorry failed converting your currencies " + result;
                }
            }
            catch
            {
                return "No connection to server";
            }
        }
    }
}
