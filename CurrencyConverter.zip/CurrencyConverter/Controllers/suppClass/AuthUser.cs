﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;
namespace CurrencyConverter.Controllers.suppClass
{
    public class AuthUser
    {
        string username;
        string password;
        public AuthUser(string user, string pass)
        {
            this.username = user;
            this.password = pass;
        }
        public bool authenticate(string user, string pass)
        {
            //fetch user name and pass from db
            /*try
            {
                var cs = "Server=127.0.0.1;Port=5432;Username=postgres;Password=Psswordjoey;Database=CurrencyConverter";
                var con = new NpgsqlConnection(cs);
                con.Open();
            }
            catch(NpgsqlException e)
            {
                throw e;
            }*/
            //couldnt complete this task cos of old version of framework that wouldnt allow 
            if (user == "admin" && pass == "admin")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
