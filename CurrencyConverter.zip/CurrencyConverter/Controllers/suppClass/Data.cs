﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CurrencyConverter.Controllers.suppClass
{
    
    public class Data
    {
        public string mitem { get; set; }
        public string mdata { get; set; }
    }
}
