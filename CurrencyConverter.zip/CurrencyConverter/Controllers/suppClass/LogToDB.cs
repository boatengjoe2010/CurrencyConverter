﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using Npgsql;
namespace CurrencyConverter.Controllers.suppClass
{
    public class LogToDB
    {
        private string requestType;
        private string currency;
        private string currency_two;
        private string amount;
        public LogToDB()
        {
        }
        public void saveLog(string api_key, string userinput)
        {
            try
            {
                //connect to db and save data
                var cs = "Host=localhost;Username=dbuser;Password=s$cret;Database=testdb";
                var con = new NpgsqlConnection(cs);
                con.Open();
            }
            catch(Exception e)
            {
                throw e;
            }



        }
    }
}
