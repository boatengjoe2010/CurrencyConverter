﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using CurrencyConverter.Controllers.suppClass;

namespace CurrencyConverter.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {

        private readonly IUserService _userService;
        private IHttpClientFactory fc;
        private ILogger<Converter> logger;

        public ValuesController(IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger, UrlEncoder encoder, IUserService userService, ISystemClock clock,  IHttpClientFactory httpClientFactory) 
        {
            _userService = userService; 
            fc = httpClientFactory;
        }

        // GET api/values
        [HttpGet()]

        public ActionResult<IEnumerable<string>> Get()
        {

            if (!Request.Headers.ContainsKey("Authorization"))
            {
                return Ok("Missing authorization header");
            }
            else
            {
                return Ok("Format for accessing is api/values/currency_from-currency_to-amount");
            }
       
        }

        // GET Format for accessing is api/values/currency_from-currency_to-amount
        //if input is in currency_from-currency_to-amount then couple conversion is done based on rate
        //else if input cannot be split api fetches the requested list of currencies with their current rates
        [HttpGet("{id}")]
        public ActionResult<string> Get(string id)
        {
            if (!Request.Headers.ContainsKey("Authorization"))
            {
                return Ok("Missing authorization header");
            }
            else
            {
                var authHeader = AuthenticationHeaderValue.Parse(Request.Headers["Authorization"]);
                var credentialBytes = Convert.FromBase64String(authHeader.Parameter);
                var credentials = System.Text.Encoding.UTF8.GetString(credentialBytes).Split(new[] { ':' }, 2);
                var username = credentials[0];
                var password = credentials[1];
                //authenticate user
                AuthUser auObj = new AuthUser(username, password);
                var result =  auObj.authenticate(username, password);
                if (result.Equals(true))
                {
                    //get input from couples from user
                    //after splitting 1st index is currency from, 2nd index is currency to, 3rd index is amount
                    var userinput = id.Split("-");
                    try
                    {
                        var currency_from = userinput[0];
                        var currency_to = userinput[1];
                        var amount = userinput[2];

                        try
                        {
                            Converter conObj = new Converter(logger, fc);
                            dynamic convalue = conObj.convert(currency_from, currency_to, amount);
                            string conval = convalue.conversion_rate;
                            var convertedamount = float.Parse(conval) * float.Parse(amount);

                            List<Data> list = new List<Data>
                            {                             
                                new Data() { mitem = "Currency_From", mdata = currency_from},
                                new Data() { mitem = "Currency_To", mdata = currency_to},
                                new Data() { mitem = "Conversion_Rate" , mdata = conval},
                                new Data() { mitem = "Amount" , mdata = convertedamount.ToString()}
                            };

                            string json = JsonConvert.SerializeObject(list);                          
                            return Ok(json);
                       }
                        catch
                        {
                            return Ok("Sorry your currency conversion was not successful. Unknown currency encountered");
                        }
                    }
                    catch
                    {
                        //this section will get the conversion rates list of requested currency
                        try
                        {
                            Converter conObj = new Converter(logger, fc);
                            dynamic convalue = conObj.getList(id);
                            string conval = convalue.conversion_rate;
                            return Ok(convalue);
                        }
                        catch
                        {
                            return Ok("Sorry your currency conversion was not successful. Unknown currency encountered");
                        }
                    }
                }
                else
                {
                    return Ok("invalid username or password");
                }
                
            }
        }

        // POST api/values
        [AllowAnonymous]
        [HttpPost("authenticate")]
        public void Post([FromBody] string value)
        {

        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }

    // this class is used to format output of couple conversion to json format
   /*class Data
    {
        public string mitem { get; set; }
        public string mdata { get; set; }
    }*/

    //this class is for logging the results
   /* public class LogToDB
    {
        private string requestType;
        private string currency;
        private string currency_two;
        private string amount;
        public LogToDB()
        {
        }
        public void saveLog(string requestType, string currency, string currency_two,string amount)
        {
            //connect to db and save data

            
        }
    }*/

    //this class is to  authenticate using username and password
   /* public class AuthUser
    {
        string username;
        string password;
        public AuthUser(string user,string pass)
        {
            this.username = user;
            this.password = pass;
        }
        public bool authenticate(string user,string pass)
        {
            //fetch user name and pass from db
            if(user=="joey" && pass == "joey")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }*/

    //this class is where we fetch the exchange rates for couple conversion 
    /*
    public class Converter
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<Converter> _logger;
        public Converter(ILogger<Converter> logger,IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            _httpClientFactory = httpClientFactory;
        }
        public object convert(string c_from, string c_to, string amount)
        {
            // fetching the exchange rate value from server
            var httpClient = _httpClientFactory.CreateClient();
            try
            {

                var response = httpClient.GetAsync("https://v6.exchangerate-api.com/v6/216ab912c6665d868050e79e/pair/"+c_from+"/"+ c_to+"/").Result;
                if (response.IsSuccessStatusCode)
                {
                    var data = response.Content.ReadAsAsync<object>().Result;
                    return data;
                }
                else
                {
                    var result = $"{(int)response.StatusCode} ({response.ReasonPhrase})";
                    return "sorry failed converting your currencies " + result;
                }
            }
            catch
            {
                return "No connection to server";
            }          
        }

        //this method is for getting requested list of currencies with their current rates
        public object getList(string currency)
        {
            // fetching the exchange rate value from server
            var httpClient = _httpClientFactory.CreateClient();
            try
            {

                var response = httpClient.GetAsync("https://v6.exchangerate-api.com/v6/216ab912c6665d868050e79e/latest/" + currency).Result;
                if (response.IsSuccessStatusCode)
                {
                    var data = response.Content.ReadAsAsync<object>().Result;
                    return data;
                }
                else
                {
                    var result = $"{(int)response.StatusCode} ({response.ReasonPhrase})";
                    return "sorry failed converting your currencies " + result;
                }
            }
            catch
            {
                return "No connection to server";
            }
        }
    }*/
}
